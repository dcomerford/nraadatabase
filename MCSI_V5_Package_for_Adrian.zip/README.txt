MCSI V5 — Package for Adrian
============================
20 June 2026

Contents
--------

1. NRAA_MCSI_V5_Committee_Report.pdf
   The complete V5 committee briefing document (revised for Adrian's
   feedback). Includes:
     - One-page committee cover (page 1)
     - Executive Summary
     - Sections 1–8: methodology, data review, statistical validation,
       and V5 recommendation
     - Section 9: Why national calibration is correct for a club
       championship
     - Appendix A: Data sources
     - Appendix B: Worked Sporter calibration example
     - Appendix C: Justification for the 0.7 centre weight

2. GRC_MCSI_Club_Champion_Master_2026_v5_with_peter.xlsx
   The Geelong club championship master spreadsheet with V4, V5 AND
   Peter's June 13 formula applied. Sheets:
     - Settings: factor tables for V2 / V3 / V4 / Peter / V5
     - Results: per-string raw scores + Adjusted V4 + Adjusted V5 +
       Adjusted Peter (3-formula side-by-side)
     - Club Champion: V4 leaderboard
     - Club Champion V5: V5 leaderboard
     - Club Champion Peter: Peter's June 13 leaderboard

V5 factors (as recommended in the report)
-----------------------------------------

  Target Rifle (TR)                       1.412
  F-Open                                  1.406
  F-Standard                              1.475
  F/TR                                    1.450
  Sporter (Open + Production merged)      1.383

  Conversion: 1.20 for TR + Sporter, 1.00 for F-class
  Centre weight: 0.70
  Formula: Adjusted MCSI = (Raw × Conversion + Centres × 0.7) × Factor

Peter's June 13 formula (for comparison)
-----------------------------------------

  TR   1.53     FO  1.39     FS  1.43
  FTR  1.39     SO  1.47     SP  1.53

  No conversion, no centre weighting.
  Formula: Adjusted = (Raw + Centres) × Factor

Key statistics
--------------

  Calibration pool:  20,335 K&Q strings, 2024+, 7 jurisdictions
  Top-40% cohort:    7,962 strings
  Factor 95% CI:     ±0.0152 (Sporter), ±0.0077 (TR) — tight on all
  Factor spread:     0.092 across all 5 disciplines (narrower than
                     commonly perceived)
  Methodology cross-check: top-40% agrees with middle-20% within ±0.02

For further work
----------------

Adrian's V6 report needs the xlsx (file #2) to compute:
  - Current championship rankings vs V5 rankings (Club Champion sheets)
  - Previous Geelong methodology rankings (Adrian to supply / re-compute)
